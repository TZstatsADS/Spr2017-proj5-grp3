data.filtered <- read.csv('NAreplaced.csv') #4242 1388
select <- read.csv('features.csv')
data.filtered <- data.filtered[,select$Codes] # 4242*63

label <- read.csv('train.csv')
label<-na.omit(label)
Index<-data.filtered$challengeID %in% label$challengeID


data.train<-data.filtered[Index,]
data.train<-as.data.frame(data.train)
data.train<-cbind(label[,-1], data.train)

# GBM
library(mlbench)
library(caret)
# Example of Boosting Algorithms
control <- trainControl(method="repeatedcv", number=10, repeats=3)
seed <- 7
metric <- "RMSE"
# Stochastic Gradient Boosting
set.seed(seed)
fit.gbm <- train(gpa~., data=data.train[,-c(2:6)], method="gbm", metric=metric, trControl=control, verbose=FALSE)
gbm_pred_gpa<-predict(fit.gbm, data.filtered[!Index,])
fit.gbm <- train(grit~., data=data.train[,-c(1,3:6)], method="gbm", metric=metric, trControl=control, verbose=FALSE)
gbm_pred_grit<-predict(fit.gbm, data.filtered[!Index,])
fit.gbm <- train(materialHardship~., data=data.train[,-c(1,2,4:6)], method="gbm", metric=metric, trControl=control, verbose=FALSE)
gbm_pred_mh<-predict(fit.gbm, data.filtered[!Index,])
metric <- "Accuracy"
fit.gbm <- train(factor(eviction)~., data=data.train[,-c(1:3,5:6)], method="gbm", metric=metric, trControl=control, verbose=FALSE)
gbm_prediction_evi<-predict(fit.gbm, data.filtered[!Index,])
fit.gbm <- train(factor(layoff)~., data=data.train[,-c(1:4,6)], method="gbm", metric=metric, trControl=control, verbose=FALSE)
gbm_prediction_lay<-predict(fit.gbm, data.filtered[!Index,])
fit.gbm <- train(factor(jobTraining)~., data=data.train[,-c(1:5)], method="gbm", metric=metric, trControl=control, verbose=FALSE)
gbm_prediction_job<-predict(fit.gbm, data.filtered[!Index,])
result<-data.frame(c(1:4242)[!Index],gbm_pred_gpa, gbm_pred_grit, gbm_pred_mh, gbm_prediction_evi, gbm_prediction_lay, gbm_prediction_job)
colnames(result)<-colnames(label)
result<-rbind(result, label)
write.csv(result, "prediction.csv", row.names = FALSE)
